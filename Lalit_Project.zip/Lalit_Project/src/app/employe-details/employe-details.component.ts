import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employe-details',
  templateUrl: './employe-details.component.html',
  styleUrls: ['./employe-details.component.css']
})
export class EmployeDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
